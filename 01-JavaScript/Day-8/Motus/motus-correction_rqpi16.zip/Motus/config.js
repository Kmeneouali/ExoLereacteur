var motus = `
___  ________ _____ _   _ _____ 
|  \\/  |  _  |_   _| | | /  ___|
| .  . | | | | | | | | | \ \`--. 
| |\\/| | | | | | | | | | |\`--. \\
| |  | \\ \\_/ / | | | |_| /\\__/ /
\\_|  |_/\\___/  \\_/  \\___/\\____/ 
\n`;
var debug = false;
var wordLength = 5;
var time = 20000;

module.exports = { motus, debug, wordLength, time };
